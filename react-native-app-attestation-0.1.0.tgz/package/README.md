# react-native-app-attestation

A complete mobile app security solution for React Native apps.

## The Problem

Without this library, anyone can send fake requests to your API:

```bash
# Anyone can do this from their terminal
curl -X POST https://api.yourapp.com/send-otp \
  -d '{"phone": "9999999999"}'

# Or loop it 1000 times
for i in {1..1000}; do
  curl -X POST https://api.yourapp.com/send-otp \
    -d '{"phone": "9999999999"}'
done
```

This leads to:
- OTP bombing — spamming any phone number with OTPs
- Fake account creation using bots
- API abuse causing server crashes
- Data scraping

## The Solution

This library proves to your server that every request comes from your **genuine, official app** installed on a **real device** — not from scripts or bots.

It does this using:
- **Android**: Google Play Integrity API — Google guarantees the request is from your genuine app
- **iOS**: Apple App Attest — Apple guarantees the request is from your genuine app

Every API request automatically includes security headers that your server can verify.

---

## How It Works

```
Your App                    Your Backend
   |                             |
   |  1. Get nonce               |
   |  ─────────────────────────> |
   |                             |
   |  2. nonce received          |
   |  <───────────────────────── |
   |                             |
   |  3. Send nonce to Google/Apple
   |  ──────────> Google/Apple   |
   |                             |
   |  4. Signed attestation token|
   |  <────────── Google/Apple   |
   |                             |
   |  5. API request with token  |
   |  ─────────────────────────> |
   |                             |
   |  6. Server verifies token   |
   |     with Google/Apple       |
   |                             |
   |  7. Request allowed         |
   |  <───────────────────────── |
```

---

## What Gets Sent With Every Request

```
POST /api/send-otp
User-Agent:      App/1.0.0 (Android)
X-App-Platform:  android
X-App-Version:   1.0.0
X-Device-ID:     8f3c7e9d-21ab-4d5e-b3c2-9a7f1e6d4c8b
X-Timestamp:     1710249381
X-Attestation:   eyJhbGciOiJSUzI1NiJ9...
```

Your server checks all of these on every request.

---

## Installation

```bash
npm install react-native-app-attestation
cd ios && pod install
```

---

## Android Setup

These steps are one-time only. You do them once when setting up the library.

### Step 1: Link your app in Google Play Console

This tells Google that your app is allowed to use Play Integrity API.

```
1. Go to play.google.com/console
2. Select your app
3. Left menu: Release → Setup → App Integrity
4. Find "Play Integrity API" section
5. Click "Link"
6. Select your Google Cloud project
7. Confirm
```

> Note: Your app must already be uploaded to Play Console at least once.

### Step 2: Enable Play Integrity API in Google Cloud

```
1. Go to console.cloud.google.com
2. Select the same project you linked above
3. Left menu: APIs & Services → Library
4. Search for "Play Integrity API"
5. Click on it → Click "ENABLE"
```

### Step 3: Add SDK to your app

In `android/app/build.gradle`:

```gradle
dependencies {
    // ... your existing dependencies
    implementation 'com.google.android.play:integrity:1.3.0'
}
```

### Step 4: Copy the native module files

Copy these two files from `node_modules/react-native-app-attestation/android/src/main/java/com/reactnativeappattestation/` into your Android project at the same path:

- `PlayIntegrityModule.kt`
- `PlayIntegrityPackage.kt`

### Step 5: Register the module

In `android/app/src/main/java/com/yourapp/MainApplication.kt`:

```kotlin
override fun getPackages(): List<ReactPackage> {
    return PackageList(this).packages.apply {
        add(PlayIntegrityPackage()) // Add this line
    }
}
```

---

## iOS Setup

These steps are one-time only.

### Step 1: Add App Attest capability in Xcode

```
1. Open your project in Xcode
2. Click your project name in the left sidebar (blue icon)
3. Select your app target
4. Click "Signing & Capabilities" tab
5. Click "+ Capability" button
6. Search for "App Attest"
7. Double click to add it
```

### Step 2: Copy the native files

Copy these files from `node_modules/react-native-app-attestation/ios/` into your iOS project folder:

- `AppAttestModule.swift`
- `AppAttestModule.m`
- `ReactNativeAppAttestation-Bridging-Header.h`

### Step 3: Set up Bridging Header

```
1. Open Xcode
2. Click your project → Select your target
3. Go to "Build Settings" tab
4. Search for "Objective-C Bridging Header"
5. Set the value to:
   YourProjectName/ReactNativeAppAttestation-Bridging-Header.h
```

---

## Code Setup

### Step 1: Initialize in App.tsx

Call `initAttestation` once when your app starts.

```typescript
import { initAttestation } from 'react-native-app-attestation';

// With MMKV (recommended)
import { MMKV } from 'react-native-mmkv';
const mmkv = new MMKV();

initAttestation({
  storage: {
    get: (key) => mmkv.getString(key) ?? null,
    set: (key, val) => mmkv.set(key, val),
    delete: (key) => mmkv.delete(key),
  },
  nonceEndpoint: 'https://api.yourapp.com/auth/nonce',
  appVersion: '1.0.0',
  debug: __DEV__,
});
```

```typescript
// With AsyncStorage
import AsyncStorage from '@react-native-async-storage/async-storage';

initAttestation({
  storage: {
    get: (key) => AsyncStorage.getItem(key),
    set: (key, val) => AsyncStorage.setItem(key, val),
    delete: (key) => AsyncStorage.removeItem(key),
  },
  nonceEndpoint: 'https://api.yourapp.com/auth/nonce',
  appVersion: '1.0.0',
});
```

---

### Step 2: Secure your API calls

#### With Axios

```typescript
import axios from 'axios';
import { setupAxios } from 'react-native-app-attestation';

const api = axios.create({
  baseURL: 'https://api.yourapp.com',
});

// One line — all requests secured automatically
setupAxios(api);

// Use api normally — security headers added behind the scenes
const response = await api.get('/user/profile');
const response = await api.post('/send-otp', { phone: '9876543210' });
```

#### With Fetch

```typescript
import { secureGet, securePost } from 'react-native-app-attestation';

// GET request
const response = await secureGet('https://api.yourapp.com/user');
const data = await response.json();

// POST request
const response = await securePost(
  'https://api.yourapp.com/login',
  { phone: '9876543210' }
);
```

#### With any other HTTP client

```typescript
import { getSecurityHeaders } from 'react-native-app-attestation';

const headers = await getSecurityHeaders();

myHttpClient.request({
  url: '/endpoint',
  headers: {
    ...headers,
    'Authorization': `Bearer ${token}`,
  }
});
```

---

### Step 3: Sensitive operations

For payments or login, always use a fresh token.

```typescript
import { getFreshAttestationToken } from 'react-native-app-attestation';

const makePayment = async (paymentData) => {
  const freshToken = await getFreshAttestationToken();

  await api.post('/payment', paymentData, {
    headers: { 'X-Attestation': freshToken }
  });
};
```

---

### Step 4: Logout

```typescript
import { clearAttestationCache } from 'react-native-app-attestation';

const logout = () => {
  clearAttestationCache();
  // ... rest of logout logic
};
```

---

## Backend Setup

### Nonce Endpoint

```javascript
// GET /auth/nonce
const crypto = require('crypto');

app.get('/auth/nonce', async (req, res) => {
  const nonce = crypto.randomBytes(32).toString('hex');

  await db.nonces.create({
    nonce,
    expiresAt: new Date(Date.now() + 5 * 60 * 1000), // 5 min
    used: false,
  });

  res.json({ nonce });
});
```

### Request Validation

```javascript
const validateRequest = async (req) => {

  // 1. Check User-Agent
  if (!req.headers['user-agent']?.includes('App/')) {
    throw new Error('Invalid client');
  }

  // 2. Reject requests older than 5 minutes
  const timestamp = parseInt(req.headers['x-timestamp']);
  const now = Math.floor(Date.now() / 1000);
  if (Math.abs(now - timestamp) > 300) {
    throw new Error('Request expired');
  }

  // 3. Check Device ID format
  const deviceId = req.headers['x-device-id'];
  if (!/^[0-9a-f-]{36}$/i.test(deviceId)) {
    throw new Error('Invalid device ID');
  }

  // 4. Verify attestation token with Google/Apple
  const isValid = await verifyAttestationToken(
    req.headers['x-attestation'],
    req.headers['x-app-platform']
  );
  if (!isValid) throw new Error('Attestation failed');
};
```

---

## Token Caching

The library caches the attestation token for 10 minutes automatically.
Google/Apple is only called once every 10 minutes — not on every request.

```
10:00 → Fresh token fetched, cached for 10 min
10:02 → API call — cached token used
10:05 → API call — cached token used
10:10 → Cache expired — fresh token fetched automatically
10:15 → Payment — getFreshAttestationToken() always bypasses cache
```

Customize cache duration:

```typescript
initAttestation({
  tokenCacheDurationMs: 5 * 60 * 1000, // 5 minutes
});
```

---

## API Reference

| Function | Description |
|----------|-------------|
| `initAttestation(config)` | Initialize once at app start |
| `setupAxios(instance)` | Setup axios interceptor |
| `secureGet(url, options?)` | Secure fetch GET |
| `securePost(url, body, options?)` | Secure fetch POST |
| `getDeviceID()` | Get persistent device UUID |
| `getAttestationToken(forceRefresh?)` | Get cached or fresh token |
| `getFreshAttestationToken()` | Always fresh — use for payments/login |
| `getSecurityHeaders()` | Get all headers as object |
| `clearAttestationCache()` | Clear cache on logout |
| `resetDeviceID()` | Delete stored device ID |

---

## Requirements

- React Native >= 0.70
- iOS >= 14.0
- Android API >= 24

---

## License

MIT