import { AttestationConfig, AttestationResult } from './types';
export declare class AttestationService {
    private config;
    private cachedToken;
    private tokenExpiry;
    private cacheDuration;
    constructor(config: AttestationConfig);
    private log;
    private fetchNonce;
    private getAndroidToken;
    private getIOSToken;
    getToken(forceRefresh?: boolean): Promise<AttestationResult>;
    getFreshToken(): Promise<AttestationResult>;
    clearCache(): void;
}
