import { SecurityHeaders } from './types';
/**
 * AXIOS ke liye
 *
 * Use karo:
 * axiosInterceptor(api, { appVersion: '1.4', getHeaders })
 */
export declare const axiosInterceptor: (axiosInstance: any, options: {
    appVersion: string;
    getHeaders: () => Promise<SecurityHeaders>;
}) => void;
/**
 * FETCH ke liye
 *
 * Use karo:
 * const res = await secureFetch(url, options, getHeaders)
 */
export declare const secureFetch: (url: string, options: RequestInit | undefined, getHeaders: () => Promise<SecurityHeaders>) => Promise<Response>;
