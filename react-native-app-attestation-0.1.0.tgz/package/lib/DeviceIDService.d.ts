import { StorageAdapter } from './types';
export declare class DeviceIDService {
    private storage;
    private debug;
    constructor(storage: StorageAdapter, debug?: boolean);
    private log;
    getDeviceID(): Promise<string>;
    resetDeviceID(): Promise<void>;
}
