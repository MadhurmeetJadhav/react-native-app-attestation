import { AttestationConfig, SecurityHeaders } from './types';
export * from './types';
export { DeviceIDService } from './DeviceIDService';
export { AttestationService } from './AttestationService';
export { axiosInterceptor, secureFetch } from './interceptors';
/**
 * App start pe ek baar call karo
 *
 * MMKV example:
 * initAttestation({
 *   storage: {
 *     get: (key) => mmkv.getString(key) ?? null,
 *     set: (key, val) => mmkv.set(key, val),
 *     delete: (key) => mmkv.delete(key),
 *   },
 *   nonceEndpoint: 'https://api.yourapp.com/auth/nonce',
 *   appVersion: '1.4',
 *   debug: __DEV__,
 * });
 */
export declare const initAttestation: (config: AttestationConfig) => void;
/**
 * Device ID lo
 */
export declare const getDeviceID: () => Promise<string>;
/**
 * Attestation token lo (cached ya fresh)
 */
export declare const getAttestationToken: (forceRefresh?: boolean) => Promise<string | null>;
/**
 * Sensitive operations ke liye fresh token
 * Payment, Login, OTP pe ye use karo
 */
export declare const getFreshAttestationToken: () => Promise<string | null>;
/**
 * Saare security headers ek saath lo
 * Interceptor mein ye use karo
 */
export declare const getSecurityHeaders: () => Promise<SecurityHeaders>;
/**
 * Axios interceptor setup
 *
 * import axios from 'axios';
 * import { initAttestation, setupAxios } from 'react-native-app-attestation';
 *
 * const api = axios.create({ baseURL: '...' });
 * setupAxios(api);
 */
export declare const setupAxios: (axiosInstance: any) => void;
/**
 * Secure fetch — fetch ki jagah use karo
 *
 * const res = await secureGet('https://api.com/user');
 */
export declare const secureGet: (url: string, options?: RequestInit) => Promise<Response>;
export declare const securePost: (url: string, body: unknown, options?: RequestInit) => Promise<Response>;
/**
 * Logout pe call karo
 */
export declare const clearAttestationCache: () => void;
/**
 * Device ID reset karo
 */
export declare const resetDeviceID: () => Promise<void>;
